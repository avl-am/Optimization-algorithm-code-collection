function [coef] = Penalty_Coefficient(funcnum)

% These penalty coefficients are set for problems 1, 3, 6, 10, 12, 13, 17, 19, 21, 22, 23....
% If you want to use another problem from benchmark suite, you should use the penalty coefficient...
% appropriate to your problem.

j=funcnum;

switch j
    case 1
        coef=0.01;
        
    case 2
        coef=100;   
        
    case 3
        coef=5000;
                
    case 4
        coef=100;
                
    case 5
        coef=100; 
        
    case 6
        coef=10000;
                
    case 7
        coef=100;
        
    case 8
        coef=1000;
                
    case 9
        coef=1000; 
        
    case 10
        coef=1000;
        
    case 11
        coef=1000;

        
end
end


