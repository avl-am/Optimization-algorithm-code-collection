function [BestX, BestF]=Agde_Case5(fhd, par, maxIteration, fNumber)

rand('state',sum(100*clock));

NP=50; 
GEN=ceil(maxIteration/NP);
D=par.n;
lbArray=par.xmin; 
ubArray=par.xmax;
lu=[lbArray; ubArray];
L=lu(1,:);
H=lu(2,:);
X=zeros(D,1); 
Pop=zeros(D,NP);
Fit=zeros(1,NP); 
BestF=inf;
BestX=[];
r=zeros(3,1); 
DELTA=ones(1,par.h)*0.0001;
DELTAinq=zeros(1,par.g);

for j = 1:NP 
    Pop(:,j) = L + (H-L).*rand(1,D);
end

[Fit, KInew]=testFunction(Pop, fhd, fNumber, par, DELTA, DELTAinq);

[~, iBest]=min(Fit);
BestF=min(Fit);

Cr_All=zeros(1,2);
NW=zeros(1,2);

frequency_epoch=1;
number_of_current_iteration=0;
counter=0;
number_of_case=2;

for g=1:GEN 

    CrPriods_Index=zeros(1,NP);
    Sr=zeros(1,2);
    CrPriods_Count=zeros(1,2);

	if mod(number_of_current_iteration,frequency_epoch)==0
        counter=counter+1;
	end
    
    switch_index=mod(counter,number_of_case);
    if switch_index==0
        switch_index=2;
    end
    
    switch switch_index  
        case 1 
            for j=1:NP 
                Ali=rand;
                if(g<=1) 
                    if (Ali<=1/2)
                        CR=0.05+0.1*rand(1,1);
                        CrPriods_Index(j)=1;
                    else
                        CR=0.9+0.1*rand(1,1);
                        CrPriods_Index(j)=2;    
                    end
                CrPriods_Count(CrPriods_Index(j))=CrPriods_Count(CrPriods_Index(j))+1;
                else
                    if (Ali<=NW(1))
                        CR=0.05+0.1*rand(1,1);
                        CrPriods_Index(j)=1; 
                    else
                        CR=0.9+0.1*rand(1,1);
                        CrPriods_Index(j)=2;    
                    end
                CrPriods_Count(CrPriods_Index(j))=CrPriods_Count(CrPriods_Index(j))+1;
                end

                f=Fit;
                [~, in]=sort(f,'ascend');
                AA=[in(1) in(2) in(3)  in(4) in(5)];
                BB=[in(46) in(47) in(48) in(49) in(50)];
                CC=[in(6) in(7) in(8) in(9) in(10) in(11) in(12) in(13) in(14) in(15) in(16) in(17) in(18)...
                    in(19) in(20) in(21) in(22) in(23) in(24) in(25) in(26) in(27) in(28) in(29) in(30) in(31)...
                    in(32) in(33) in(34) in(35) in(36) in(37) in(38) in(39) in(40) in(41) in(42) in(43) in(44) in(45)];

                paraIndex=floor(rand(1,1)*length(AA))+1;
                paraIndex1=floor(rand(1,1)*length(BB))+1;
                paraIndex2=floor(rand(1,1)*length(CC))+1;

                r(1) = Fitness_Constraint_v1(Pop', Fit, KInew);                
                r(2) = BB(paraIndex1);
                r(3) = CC(paraIndex2);

                F=0.1+0.9*rand(1,1);
                Rnd=floor(rand()*D) + 1;
                for i=1:D
                    if (rand()<CR)||(Rnd==i)
                        X(i)=Pop(i,r(3))+F*(Pop(i,r(1))-(Pop(i,r(2))));
                    else
                        X(i) = Pop(i,j);
                    end
                end

                for i=1:D
                    if (X(i)<L(i))||(X(i)>H(i))
                        X(i) = L(i)+(H(i)-L(i))*rand();
                    end
                end

                [fitness, KI]=testFunction(X, fhd, fNumber, par, DELTA, DELTAinq); 

                if fitness<=Fit(j)
                    Sr(CrPriods_Index(j))=Sr(CrPriods_Index(j))+1;
                    Pop(:,j)=X; 
                    Fit(j)=fitness ;
                    KInew(j,:)=KI;
                    if fitness<=Fit(iBest)
                        iBest=j; 
                    end
                end
            end

            
        case 2 
            for j=1:NP 
                Ali=rand;
                if(g<=1) 
                    if (Ali<=1/2)
                        CR=0.05+0.1*rand(1,1);
                        CrPriods_Index(j)=1;
                    else
                        CR=0.9+0.1*rand(1,1);
                        CrPriods_Index(j)=2;    
                    end
                CrPriods_Count(CrPriods_Index(j))=CrPriods_Count(CrPriods_Index(j))+1;
                else
                    if (Ali<=NW(1))
                        CR=0.05+0.1*rand(1,1);
                        CrPriods_Index(j)=1; 
                    else
                        CR=0.9+0.1*rand(1,1);
                        CrPriods_Index(j)=2;    
                    end
                CrPriods_Count(CrPriods_Index(j))=CrPriods_Count(CrPriods_Index(j))+1;
                end

                f=Fit;
                [~, in]=sort(f,'ascend');
                AA=[in(1) in(2) in(3)  in(4) in(5)];
                BB=[in(46) in(47) in(48) in(49) in(50)];
                CC=[in(6) in(7) in(8) in(9) in(10) in(11) in(12) in(13) in(14) in(15) in(16) in(17) in(18)...
                    in(19) in(20) in(21) in(22) in(23) in(24) in(25) in(26) in(27) in(28) in(29) in(30) in(31)...
                    in(32) in(33) in(34) in(35) in(36) in(37) in(38) in(39) in(40) in(41) in(42) in(43) in(44) in(45)];

                paraIndex=floor(rand(1,1)*length(AA))+1;
                paraIndex1=floor(rand(1,1)*length(BB))+1;
                paraIndex2=floor(rand(1,1)*length(CC))+1;
                
                [index1, index2, index3]=Fitness_Distance_Constraint_v2(Pop', Fit, KInew);  
                indexes=[index1 index2 index3];         
        
                for k=1:3
                    r(1)=AA(k);  
                    r(2)=indexes(k);
                    r(3)=CC(paraIndex2);

                    F=0.1+0.9*rand(1,1);
                    Rnd=floor(rand()*D)+1;
                    for i = 1:D
                        if (rand()<CR)||(Rnd==i)
                            X(i)=Pop(i,r(3))+F*(Pop(i,r(1))-(Pop(i,r(2))));
                        else
                            X(i)=Pop(i,j);
                        end
                    end
                    [fitness, KI]=testFunction(X, fhd, fNumber, par, DELTA, DELTAinq); 

                    if fitness<=Fit(j)
                        Sr(CrPriods_Index(j))=Sr(CrPriods_Index(j))+1;
                        Pop(:,j)=X; 
                        Fit(j)=fitness ;
                        KInew(j,:)=KI;
                        if fitness<=Fit(iBest)
                            iBest=j; 
                        end
                    end
                end
            end
    end
    
    CrPriods_Count(CrPriods_Count==0)=0.0001;
    Sr=Sr./CrPriods_Count;
    
    if(sum(Sr)==0)
        W=[1/2 1/2];
    else
        W=Sr/sum(Sr);
    end
    
    NW=(NW*(g-1)+W)/g;
    Cr_All=Cr_All+CrPriods_Count;
end

    fitness=Fit(iBest);
    BestF=fitness;
    BestX=Pop(:,iBest)';
    
end