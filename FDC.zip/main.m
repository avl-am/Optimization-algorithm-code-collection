clc
clear all;
paths;

% This benchmark problem set was proposed by Kumar et al. in 
% "A Test-suite of Non-Convex Constrained Optimization Problems from the Real-World and Some Baseline Results".
%In original cec2020 benchmark suite, 57 real-world constrained optimization problem are given....
% In this study, the problems including 1, 3, 6, 10, 12, 13, 17, 19, 21, 22, 23 were used. 
% If you want to use another problem from this benchmark suite,you can update the main file accordingly.

global globalMin; 
global penalty_coef;

cec20rw=str2func('cec20_func_rw');

%feasible solution of the number of benchmark functions used in the study.
feasible=[1.8931162966E+02, -4.5291197395E+03, 1.8638304088E+00, ...
          1.0765430833E+00, 2.9248305537E+00, 2.6887000000E+04, ...
          1.2665232788E-02, 1.6702177263E+00, 2.3524245790E-01, 5.2576870748E-01, 1.6069868725E+01];

algorithms = {'Agde_Case1', 'Agde_Case2', 'Agde_Case3', 'Agde_Case4', 'Agde_Case5', 'Agde_Case6', 'Agde_Case7'};

functions = [1:11];
run = 25;

algorithmsNumber = length(algorithms);
funcnum=[1 3 6 10 12 13 17 19 21 22 23]; 

for ii = 1:algorithmsNumber
    disp(algorithms(ii));
    algorithm = str2func(char(algorithms(ii)));
    for k = 1:11
        i=funcnum(k);
        disp(i);
        func_num=i;
        Function_name=['func_num',num2str(i)];
        [par]=Cal_par(i); 
        bestpos=zeros(run,par.n);
       
        if par.n <= 10
            maxIteration = 10^5;
        elseif par.n>10 &&  par.n<=30
            maxIteration = 2*10^5;
        elseif par.n>30 &&  par.n<=50
            maxIteration = 4*10^5;
        elseif par.n>50 &&  par.n<=150
            maxIteration = 8*10^5;
        else
            maxIteration = 10^6;
        end
     
        for j=1:run
            globalMin = 10^10;   
            penalty_coef = Penalty_Coefficient(k); 
            [bestposition, bestFitness] = algorithm(cec20rw, par, maxIteration, func_num);
        end
    end
end

