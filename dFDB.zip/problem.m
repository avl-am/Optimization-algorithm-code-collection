function [ y ] = problem( x )

    y = sum(x.^2);

end

